************************************************************************
This file is part of a package from:
www.freecontactform.com

Free Version
11 January 2021

You are free to use for your own use. 
You cannot resell or repackage in any way.

Important legal notice:
You MUST retain the attribution to www.freecontactform.com 
It must be visible on the same page as the form.
Or switch to the Pro version without attribution/credit.

****************************************************************************


Thank you for picking freecontactform.com


Quick guide on how to add to your website:

    1. Open the file: fcf-assets/fcf.config.php
    2. Add your email address to the part highlighted below:
        define('EMAIL_TO', 'your email address in here');
    3. Add your email address (this email address must be known by your hosting environment) to the part highlighted below:
        define('EMAIL_FROM', 'your email address in here');
    4. Save
    5. Add the content of fcf.form.htm to your contact page.
    6. Upload ALL files (including the folder fcf-assets to your website)


More detailed installation details can be found at: 

https://www.freecontactform.com/form-guides/contact-form-installation-free


Please tell us what you think:

Let us know if you liked it or not, or just say thanks.
All feedback is very much appreciated!

This is important as it helps us want to make future improvements.

https://www.freecontactform.com/contact


Thanks again and have a great day!

Stuart Cochrane (Owner and Developer at freecontactform.com)